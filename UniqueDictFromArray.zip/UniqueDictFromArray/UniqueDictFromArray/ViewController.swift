//
//  ViewController.swift
//  UniqueDictFromArray
//
//  Created by Tejora on 22/08/19.
//  Copyright © 2019 Tejora. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate {

    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtName.delegate = self
        self.btnLogin.setBgColor()
        // Do any additional setup after loading the view.
        
  //  let filterRecords = self.getUniqueDictFromArrayBaseOnKey(keyVal: "Name")
    //    print("\(filterRecords)")
    }

    func getUniqueDictFromArrayBaseOnKey(keyVal : String!) -> [[String : Any]] {
        let array: [[String : Any]] = [["Id":"01", "Name":"Alice", "Age":"15"],
                                       ["Id":"02", "Name":"Bob", "Age":"53"],
                                       ["Id":"03", "Name":"Cathy", "Age":"12"],
                                       ["Id":"04", "Name":"Bob", "Age":"83"],
                                       ["Id":"05", "Name":"Denise", "Age":"88"],
                                       ["Id":"06", "Name":"Alice", "Age":"44"]]
        
        var set = Set<String>()
        let arraySet: [[String : Any]] = array.compactMap {
            guard let name = $0[keyVal] as? String else {return nil }
            return set.insert(name).inserted ? $0 : nil
        }
        return arraySet
    }
}




