//
//  FontStylingExtension.swift
//  UniqueDictFromArray
//
//  Created by Tejora on 18/02/20.
//  Copyright © 2020 Tejora. All rights reserved.
//

import Foundation
import UIKit


// MARK: LABLE FONT STYLE
extension UILabel {
    
   @objc var substituteFontName : String {
        get { return self.font.fontName }
        set {
            let fontNameToTest = self.font?.fontName.lowercased() ?? "";
            var fontName = newValue;
            if fontNameToTest.range(of: "bold") != nil {
                fontName += "-Bold";
            } else if fontNameToTest.range(of: "medium") != nil {
                fontName += "-Medium";
            } else if fontNameToTest.range(of: "light") != nil {
                fontName += "-Light";
            } else if fontNameToTest.range(of: "thin") != nil {
                fontName += "-Thin";
            }else if fontNameToTest.range(of: "regular") != nil {
                fontName += "-Regular";
            } else if fontNameToTest.range(of: "semibold") != nil {
                fontName += "-Semibold";
            } else if fontNameToTest.range(of: "ultralight") != nil {
                fontName += "-UltraLight";
            }
            self.font = UIFont(name: fontName, size: (self.font?.pointSize)!)
            }
    }
}


// MARK: TEXTFIELD FONT STYLE
extension UITextField {
    @objc var substituteFontName : String {
        get { return self.font!.fontName }
        set {
        let fontNameToTest = self.font?.fontName.lowercased() ?? "";
        var fontName = newValue;
        if fontNameToTest.range(of: "bold") != nil {
            fontName += "-Bold";
        } else if fontNameToTest.range(of: "medium") != nil {
            fontName += "-Medium";
        } else if fontNameToTest.range(of: "light") != nil {
            fontName += "-Light";
        } else if fontNameToTest.range(of: "thin") != nil {
            fontName += "-Thin";
        }else if fontNameToTest.range(of: "regular") != nil {
            fontName += "-Regular";
        } else if fontNameToTest.range(of: "semibold") != nil {
            fontName += "-Semibold";
        } else if fontNameToTest.range(of: "ultralight") != nil {
            fontName += "-UltraLight";
        }
        self.font = UIFont(name: fontName, size: (self.font?.pointSize)!)
        }
    }
}

extension UIFont {
    class func appRegularFontWith( size:CGFloat ) -> UIFont {
        return  UIFont(name: "AvenirNext-UltraLight", size: size)!
    }
    
    class func appBoldFontWith( size:CGFloat ) -> UIFont{
        return  UIFont(name: "AvenirNext-Bold", size: size)!
    }
}

// MARK: REFER BELOW LINK -
// https://stackoverflow.com/questions/28180449/using-custom-font-for-entire-ios-app-swift/28180645


// MARK: UIBUTTON THEMECOLOR
extension UIButton {
    func setBgColor() {
        self.backgroundColor = mainThemeColor
    }
}
