//
//  Constant.swift
//  UniqueDictFromArray
//
//  Created by Tejora on 18/02/20.
//  Copyright © 2020 Tejora. All rights reserved.
//

import UIKit


// MARK: GLOBAL VARIABLE
let appLabelFontName = "AvenirNext"
let appTxtFieldFontName = "AvenirNext"

// MARK: COLORS
let redTheme = UIColor(red: 1, green: 0.1, blue: 0.1, alpha: 1)
let greenTheme = UIColor(red: 0, green: 1, blue: 0, alpha: 1)
let blueTheme = UIColor(red: 0, green: 0.2, blue: 0.9, alpha: 1)
/* mainThemeColor used to set theme for entire app*/
let mainThemeColor = blueTheme
